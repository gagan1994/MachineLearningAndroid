package com.example.gagan.mlandroid.type;

/**
 * Created by Gagan on 6/8/2018.
 */

public enum  Detectors {
    FACE,
    TEXT,
    BARCODE,
    IMAGE,
    LANDMARKS
}
