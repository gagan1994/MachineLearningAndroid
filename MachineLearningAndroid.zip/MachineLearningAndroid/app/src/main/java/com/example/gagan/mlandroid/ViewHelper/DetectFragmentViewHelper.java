package com.example.gagan.mlandroid.ViewHelper;

import android.graphics.Bitmap;
import android.net.Uri;

/**
 * Created by Gagan on 6/8/2018.
 */

public interface DetectFragmentViewHelper {
    void setInfoText(String s);

    void setImageBitMap(Bitmap bitMap);

    void setImamgeUri(Uri uri);
}
